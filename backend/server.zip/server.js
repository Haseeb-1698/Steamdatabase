const express = require('express');
const mongoose = require('mongoose');
const morgan = require('morgan'); // Make sure to require morgan
require('dotenv').config();
const axios = require('axios');
const { News, GlobalAchievement, PlayerSummary, OwnedGames, RecentlyPlayedGames } = require('./models/models'); // Import your models
const { request } = require('express');

// Initialize express app
const app = express();

// Use morgan middleware for logging
app.use(morgan('dev')); // Logs requests to the console in development mode

// Your existing MongoDB connection setup and other middleware
const connection = mongoose.connection;

connection.on('error', console.error.bind(console, 'connection error:'));
connection.once('open', function() {
  console.log('MongoDB database connection established successfully');
});




app.get('/fetchAllNews', async (req, res) => {
  try {
    const allNews = await News.find({}); // Finds all documents in the News collection
    res.json(allNews);
  } catch (error) {
    console.error('Error fetching all news: ', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});


// Fetch and save news for a specific game
app.get('/fetchNews/:appid', async (req, res) => {
  const appid = req.params.appid;

  try {
    const url = `http://api.steampowered.com/ISteamNews/GetNewsForApp/v0002/?appid=${appid}&format=json&count=3`; // Set count or any other parameters as needed
    const response = await axios.get(url);

    if (response.data && response.data.appnews && response.data.appnews.newsitems) {
      const newsItems = response.data.appnews.newsitems;

      // Create or update the news entry for the game
      const news = await News.findOneAndUpdate({ appid: appid }, {
        appid: appid,
        newsitems: newsItems,
        count: newsItems.length
      }, { new: true, upsert: true }); // 'upsert' option will create the document if it does not exist

      res.json(news); // Send back the news data as JSON
    } else {
      res.status(404).json({ message: 'No news found for this appid' });
    }
  } catch (error) {
    console.error('Error fetching news: ', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});
app.post('/addDummyNews', async (req, res) => {
  ;

  // Example list of news items to add
  const dummyNewsItems = [
    {
      gid: "1",
      title: "Exciting Game Update",
      url: "https://example.com/news/1",
      is_external_url: true,
      author: "Game Developer",
      contents: "We're excited to announce a new update...",
      feedlabel: "Updates",
      date: new Date(),
      feedname: "developer_updates",
      feed_type: 1
    },
    {
      gid: "2",
      title: "Scheduled Maintenance",
      url: "https://example.com/news/2",
      is_external_url: true,
      author: "Game Ops Team",
      contents: "There will be a scheduled game maintenance...",
      feedlabel: "Maintenance",
      date: new Date(),
      feedname: "maintenance",
      feed_type: 2
    }
    // Add more dummy items as needed
  ];

  try {
    // Add the dummy news items for the given appid
    const news = await News.findOneAndUpdate(
      { appid: appid },
      {
        $push: { newsitems: { $each: dummyNewsItems } },
        $inc: { count: dummyNewsItems.length }
      },
      { new: true, upsert: true }
    );

    res.json({ message: "News items added successfully", news });
  } catch (error) {
    console.error('Error adding dummy news: ', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

app.use((req, res, next) => {
    res.header('Content-Type', 'application/json');
    res.header('Access-Control-Allow-Origin', '*'); // Be cautious with CORS in production
    next();
  });
  app.use((err, req, res, next) => {
    const statusCode = err.statusCode || 500;
    console.error(err.message, err.stack);
    res.status(statusCode).json({ message: err.message || 'Internal Server Error' });
  });
  
    
// Other routes would follow a similar pattern, fetching different types of data and saving it to their respective collections
app.get('*', (request, response) => {
    response.status(404).json({ message: 'Not Found' });
  });
// Generic error handler - this should be the last middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Something broke!');
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});