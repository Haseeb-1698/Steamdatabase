const mongoose = require('mongoose');

// News Item Subdocument Schema
const NewsItemSchema = new mongoose.Schema({
  gid: String,
  title: String,
  url: String,
  is_external_url: Boolean,
  author: String,
  contents: String,
  feedlabel: String,
  date: Date,
  feedname: String,
  feed_type: Number
});

// News Model Schema
const NewsSchema = new mongoose.Schema({
  appid: { type: Number, required: true },
  newsitems: [NewsItemSchema],
  count: Number
});

// Achievement Subdocument Schema
const AchievementSchema = new mongoose.Schema({
  name: String,
  percent: Number
});

// Global Achievement Model Schema
const GlobalAchievementSchema = new mongoose.Schema({
  gameid: { type: Number, required: true },
  achievements: [AchievementSchema]
});

// Avatar Subdocument Schema
const AvatarSchema = new mongoose.Schema({
  small: String,
  medium: String,
  full: String
});

// Player Summary Model Schema
const PlayerSummarySchema = new mongoose.Schema({
  steamid: { type: String, required: true },
  personaname: String,
  profileurl: String,
  avatar: AvatarSchema,
  personastate: Number,
  communityvisibilitystate: Number,
  profilestate: Number,
  lastlogoff: Date,
  commentpermission: Boolean
});

// Game Subdocument Schema (used for OwnedGames and RecentlyPlayedGames)
const GameSchema = new mongoose.Schema({
  appid: Number,
  playtime_forever: Number,
  playtime_2weeks: { type: Number, default: 0 },
  // Additional fields for more detailed game information
  playtime_windows_forever: Number,
  playtime_mac_forever: Number,
  playtime_linux_forever: Number,
  playtime_deck_forever: Number,
  rtime_last_played: Date,
  playtime_disconnected: Number,
  img_icon_url: String
});

// Owned Games Model Schema
const OwnedGamesSchema = new mongoose.Schema({
  steamid: { type: String, required: true },
  game_count: Number,
  games: [GameSchema]
});

// Recently Played Games Model Schema
const RecentlyPlayedGamesSchema = new mongoose.Schema({
  steamid: { type: String, required: true },
  total_count: Number,
  games: [GameSchema] // Reusing the GameSchema
});

// Compiling models from the above schemas
const News = mongoose.model('News', NewsSchema);
const GlobalAchievement = mongoose.model('GlobalAchievement', GlobalAchievementSchema);
const PlayerSummary = mongoose.model('PlayerSummary', PlayerSummarySchema);
const OwnedGames = mongoose.model('OwnedGames', OwnedGamesSchema);
const RecentlyPlayedGames = mongoose.model('RecentlyPlayedGames', RecentlyPlayedGamesSchema);

// Export the models
module.exports = {
  News,
  GlobalAchievement,
  PlayerSummary,
  OwnedGames,
  RecentlyPlayedGames
};
